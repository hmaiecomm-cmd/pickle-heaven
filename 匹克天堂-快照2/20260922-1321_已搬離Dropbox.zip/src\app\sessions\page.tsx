import type { Metadata } from 'next'
import { RegistrationStatus, SessionStatus } from '@prisma/client'
import { prisma } from '@/lib/db'
import { zonedParts } from '@/lib/timezone'
import { Card, CardContent } from '@/components/ui/card'

export const metadata: Metadata = { title: '球敘' }
export const dynamic = 'force-dynamic'

const WEEKDAYS = ['日', '一', '二', '三', '四', '五', '六'] as const

const STATUS_LABEL: Record<SessionStatus, { text: string; tone: string }> = {
  DRAFT: { text: '草稿', tone: 'bg-ink-100 text-ink-600 dark:bg-ink-800 dark:text-ink-300' },
  SCHEDULED: { text: '尚未開放', tone: 'bg-ink-100 text-ink-600 dark:bg-ink-800 dark:text-ink-300' },
  OPEN: { text: '開放報名', tone: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' },
  FULL: { text: '已額滿', tone: 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300' },
  LOCKED: { text: '已鎖定', tone: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' },
  PLAYING: { text: '進行中', tone: 'bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-300' },
  COMPLETED: { text: '已結束', tone: 'bg-ink-100 text-ink-600 dark:bg-ink-800 dark:text-ink-300' },
  CANCELLED: { text: '已取消', tone: 'bg-ink-100 text-ink-500 dark:bg-ink-800 dark:text-ink-400' },
}

function fmtDate(date: Date, tz: string) {
  const p = zonedParts(date, tz)
  return `${p.month}/${p.day}（${WEEKDAYS[p.weekday]}）`
}

function fmtTime(date: Date, tz: string) {
  const p = zonedParts(date, tz)
  return `${String(p.hour).padStart(2, '0')}:${String(p.minute).padStart(2, '0')}`
}

function fmtDateTime(date: Date, tz: string) {
  return `${fmtDate(date, tz)} ${fmtTime(date, tz)}`
}

export default async function SessionsPage() {
  const sessions = await prisma.session.findMany({
    where: { status: { not: SessionStatus.CANCELLED } },
    orderBy: { startAt: 'asc' },
    take: 20,
    include: {
      venue: { select: { name: true, timezone: true } },
      court: { select: { name: true } },
      registrations: {
        where: { status: { in: [RegistrationStatus.CONFIRMED, RegistrationStatus.WAITLISTED] } },
        select: { status: true },
      },
    },
  })

  if (sessions.length === 0) {
    return (
      <div className="mx-auto max-w-lg px-4 py-10">
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted">
            目前沒有球敘。請先執行{' '}
            <code className="rounded surface-2 px-1.5 py-0.5">npm run db:seed</code> 建立範本，
            再呼叫 <code className="rounded surface-2 px-1.5 py-0.5">/api/cron/sessions</code> 產生場次。
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-lg space-y-4 px-4 py-6">
      <header className="space-y-1">
        <h1 className="text-lg font-semibold">🏓 球敘</h1>
        <p className="text-xs text-muted">
          由排程依範本自動產生，狀態也由排程推進（共 {sessions.length} 場）
        </p>
      </header>

      {sessions.map((s) => {
        const tz = s.venue.timezone
        const confirmed = s.registrations.filter(
          (r) => r.status === RegistrationStatus.CONFIRMED,
        ).length
        const waiting = s.registrations.filter(
          (r) => r.status === RegistrationStatus.WAITLISTED,
        ).length
        const publicSpots = Math.max(0, s.capacity - s.reservedCapacity)
        const label = STATUS_LABEL[s.status]

        return (
          <Card key={s.id}>
            <CardContent className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="text-sm font-semibold">🏓 {s.title}</h2>
                  <p className="mt-0.5 text-lg font-semibold tabular-nums">
                    {fmtDate(s.startAt, tz)} {fmtTime(s.startAt, tz)}–{fmtTime(s.endAt, tz)}
                  </p>
                </div>
                <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${label.tone}`}>
                  {label.text}
                </span>
              </div>

              <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted">
                <span>📍 {s.court?.name ?? s.venue.name}</span>
                {s.skillLevelMin != null && s.skillLevelMax != null ? (
                  <span>程度 {s.skillLevelMin.toFixed(1)}–{s.skillLevelMax.toFixed(1)}</span>
                ) : null}
                <span>💰 NT${s.price}</span>
              </div>

              <div className="flex items-center gap-3 text-sm">
                <span className="font-medium tabular-nums">
                  👥 {confirmed} / {publicSpots}
                </span>
                {s.reservedCapacity > 0 ? (
                  <span className="text-xs text-muted">（另保留 {s.reservedCapacity} 席）</span>
                ) : null}
                {waiting > 0 ? (
                  <span className="text-xs text-muted">候補 {waiting} 人</span>
                ) : null}
              </div>

              <dl className="space-y-1 border-t border-[rgb(var(--border))] pt-3 text-xs text-muted">
                <div className="flex justify-between">
                  <dt>報名開放</dt>
                  <dd className="tabular-nums">{fmtDateTime(s.bookingOpenAt, tz)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>取消截止</dt>
                  <dd className="tabular-nums">{fmtDateTime(s.cancelDeadline, tz)}</dd>
                </div>
              </dl>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
