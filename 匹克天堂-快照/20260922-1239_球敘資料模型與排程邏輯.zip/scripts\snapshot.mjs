/**
 * 專案快照（不使用 git 時的替代方案）。
 *
 *   npm run snapshot              建立快照
 *   npm run snapshot -- 說明文字   建立快照並加註說明
 *
 * 會把專案打包成 zip 放到 ../匹克天堂-快照/ ，
 * 排除 node_modules、.next 等可重建的目錄。
 * 刻意放在專案「外面」，避免快照又被下一次快照包進去。
 */
import { execFileSync } from 'node:child_process'
import { mkdirSync, existsSync, readdirSync, statSync, writeFileSync, rmSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { tmpdir } from 'node:os'

const projectDir = resolve(import.meta.dirname, '..')
const outDir = resolve(projectDir, '..', '匹克天堂-快照')

const now = new Date()
const pad = (n) => String(n).padStart(2, '0')
const stamp =
  `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}` +
  `-${pad(now.getHours())}${pad(now.getMinutes())}`

const note = process.argv.slice(2).join(' ').trim()
const safeNote = note.replace(/[\/:*?"<>|]/g, '-')
const zipPath = join(outDir, safeNote ? `${stamp}_${safeNote}.zip` : `${stamp}.zip`)

// node_modules 可由 npm install 重建；.next 是建置產物；desktop.ini 是 Dropbox 系統檔。
const EXCLUDE = ['node_modules', '.next', '.git', 'tsconfig.tsbuildinfo', 'desktop.ini']

if (!existsSync(outDir)) mkdirSync(outDir, { recursive: true })

const items = readdirSync(projectDir).filter((n) => !EXCLUDE.includes(n))

// 專案路徑含中文，直接當命令列參數傳給 powershell.exe 會因編碼而失敗。
// 改成寫出一支 UTF-8 BOM 的 .ps1 再執行，PowerShell 就能正確讀到中文路徑。
const quote = (p) => `'${p}'`
const script =
  `$ErrorActionPreference = 'Stop'\r\n` +
  `Set-Location -LiteralPath ${quote(projectDir)}\r\n` +
  `Compress-Archive -LiteralPath ${items.map(quote).join(',')} ` +
  `-DestinationPath ${quote(zipPath)} -Force\r\n`

const ps1 = join(tmpdir(), `pickle-snapshot-${Date.now()}.ps1`)
writeFileSync(ps1, '\uFEFF' + script, 'utf8')

try {
  execFileSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ps1], {
    stdio: 'inherit',
  })
} finally {
  rmSync(ps1, { force: true })
}

const mb = (statSync(zipPath).size / 1024 / 1024).toFixed(1)
console.log(`\n✅ 快照已建立（${mb} MB）`)
console.log(`   ${zipPath}`)
