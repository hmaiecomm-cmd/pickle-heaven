'use server'

import { revalidatePath } from 'next/cache'
import { CancellationMode } from '@prisma/client'
import { prisma } from '@/lib/db'
import { requireAdmin } from '@/lib/admin-auth'
import { generateUpcomingSessions } from './session-scheduler'

/**
 * 週期性球敘範本的管理（規格 §10、§14、§20）。
 *
 * 範本只描述「每週幾、幾點到幾點、幾人、什麼規則」，實際場次由排程依範本產生。
 * 這裡改動範本後只影響之後產生的場次，已存在的場次不會被回溯修改——
 * 否則已經報名的人會突然發現規則變了。
 */

export type TemplateResult = { ok: boolean; message: string }

export type TemplateInput = {
  title: string
  weekday: number
  startMinute: number
  endMinute: number
  capacity: number
  reservedCapacity: number
  skillLevelMin: number | null
  skillLevelMax: number | null
  price: number
  bookingOpenDaysBefore: number
  bookingOpenHourOffset: number
  cancellationMode: CancellationMode
  cancellationHoursBefore: number | null
  waitlistEnabled: boolean
  autoPromote: boolean
  allowPostLockReplacement: boolean
  generateWeeksAhead: number
  active: boolean
}

function validate(input: TemplateInput): string | null {
  if (!input.title.trim()) return '請輸入名稱'
  if (input.weekday < 0 || input.weekday > 6) return '星期設定不正確'
  if (input.endMinute <= input.startMinute) return '結束時間必須晚於開始時間'
  if (input.capacity < 1) return '容量至少要 1 人'
  if (input.reservedCapacity < 0 || input.reservedCapacity >= input.capacity) {
    return '保留名額必須小於總容量'
  }
  if (input.price < 0) return '價格不能是負數'
  if (input.bookingOpenDaysBefore < 0) return '報名開放天數不能是負數'
  if (input.generateWeeksAhead < 1 || input.generateWeeksAhead > 52) {
    return '預先產生週數請設在 1–52 之間'
  }
  if (
    input.cancellationMode === CancellationMode.HOURS_BEFORE_START &&
    (input.cancellationHoursBefore == null || input.cancellationHoursBefore < 0)
  ) {
    return '請填寫開打前幾小時截止'
  }
  return null
}

export async function createTemplate(input: TemplateInput): Promise<TemplateResult> {
  await requireAdmin()

  const error = validate(input)
  if (error) return { ok: false, message: error }

  const venue = await prisma.venue.findFirst({ where: { active: true }, orderBy: { name: 'asc' } })
  if (!venue) return { ok: false, message: '尚未建立任何場館' }

  await prisma.sessionTemplate.create({
    data: { ...input, title: input.title.trim(), organizationId: venue.organizationId, venueId: venue.id },
  })

  revalidatePath('/admin/templates')
  return { ok: true, message: '範本已建立。執行排程後就會產生場次。' }
}

export async function updateTemplate(id: string, input: TemplateInput): Promise<TemplateResult> {
  await requireAdmin()

  const error = validate(input)
  if (error) return { ok: false, message: error }

  await prisma.sessionTemplate.update({
    where: { id },
    data: { ...input, title: input.title.trim() },
  })

  revalidatePath('/admin/templates')
  return { ok: true, message: '範本已更新。已產生的場次不受影響。' }
}

export async function toggleTemplate(id: string, active: boolean): Promise<TemplateResult> {
  await requireAdmin()
  await prisma.sessionTemplate.update({ where: { id }, data: { active } })
  revalidatePath('/admin/templates')
  return { ok: true, message: active ? '範本已啟用' : '範本已停用，不再產生新場次' }
}

/** 立刻依所有啟用中的範本補足未來場次，不必等排程。 */
export async function generateNow(): Promise<TemplateResult> {
  await requireAdmin()

  const result = await generateUpcomingSessions()
  revalidatePath('/admin/templates')
  revalidatePath('/admin/sessions')
  revalidatePath('/sessions')

  return {
    ok: true,
    message: `新增 ${result.sessionsCreated} 場，已存在 ${result.alreadyExisted} 場`,
  }
}
